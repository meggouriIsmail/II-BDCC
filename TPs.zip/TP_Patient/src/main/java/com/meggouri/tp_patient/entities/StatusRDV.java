package com.meggouri.tp_patient.entities;

public enum StatusRDV {
    PENDING,
    CANCELED,
    DONE
}
