package com.meggouri.tp_patient.repositories;

import com.meggouri.tp_patient.entities.RendezVous;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RendezVousRepo extends JpaRepository<RendezVous, Long> {
}
